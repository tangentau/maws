<?php

/**
 * sfGuardGroupPermission form.
 *
 * @package    form
 * @subpackage sf_guard_group_permission
 * @version    SVN: $Id: sfGuardGroupPermissionForm.class.php 7745 2008-03-05 11:05:33Z fabien $
 */
class sfGuardGroupPermissionForm extends BasesfGuardGroupPermissionForm
{
  public function configure()
  {
  }
}
