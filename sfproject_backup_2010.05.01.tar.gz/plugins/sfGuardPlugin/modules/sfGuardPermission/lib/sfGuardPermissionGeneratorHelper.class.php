<?php

/**
 * sfGuardPermission module helper.
 *
 * @package    sfGuardPlugin
 * @subpackage sfGuardPermission
 * @author     Fabien Potencier
 * @version    SVN: $Id: sfGuardPermissionGeneratorHelper.class.php 12896 2008-11-10 19:02:34Z fabien $
 */
class sfGuardPermissionGeneratorHelper extends BaseSfGuardPermissionGeneratorHelper
{
}
