<h2>Не удалось удалить ленту.</h2>
<?php foreach ($errors as $error):?>
  <div class="error_message"><?php echo $error?></div>
<?php endforeach; ?>