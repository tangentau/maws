<h1>Редактирование пользовательских настроек</h1>

<?php include_partial('form', array('form' => $form)) ?>

<div class="links_list">
  <a href="<?php echo url_for('user/index') ?>">К списку пользователей</a>
</div>
