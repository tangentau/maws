<h1>Добавление новой сводки</h1>

<?php include_partial('page_form', array('form' => $form, 'errors' => $errors)) ?>

<div class="links_list">
  <a href="<?php echo url_for('page/index') ?>">Перейти к списку сводок</a>
</div>