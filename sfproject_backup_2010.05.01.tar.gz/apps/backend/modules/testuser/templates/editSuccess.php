<h1>Edit SfGuardUser</h1>

<?php include_partial('form', array('form' => $form)) ?>
