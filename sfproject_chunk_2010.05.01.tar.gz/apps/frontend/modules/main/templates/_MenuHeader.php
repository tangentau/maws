<div class="header_menu">
  <?php echo link_to('Главная', 'main/index') ?>
  <?php echo link_to('Фильтры', 'parser/index') ?>
  <?php echo link_to('Ленты', 'thread/index') ?>
  <?php echo link_to('Сводки', 'page/index') ?>
  <?php echo link_to('Справка', 'main/help') ?>
</div>