<h1>Edit MawsPage</h1>

<?php include_partial('form', array('form' => $form)) ?>
