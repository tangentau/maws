<h1>Добавление нового фильтра</h1>

<?php include_partial('parser_form', array('form' => $form, 'errors' => $errors)) ?>

<div class="links_list">
  <a href="<?php echo url_for('parser/index') ?>">Перейти к списку фильтров</a>
</div>