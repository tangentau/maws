<h1>Edit MawsPageThread</h1>

<?php include_partial('form', array('form' => $form)) ?>
